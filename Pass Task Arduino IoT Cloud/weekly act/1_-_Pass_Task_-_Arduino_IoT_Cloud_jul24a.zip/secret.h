#define SECRET_SSID "Long's hotspot"
#define SECRET_OPTIONAL_PASS "123456677"
Arduino Cloud historic data

variables:
  - id: cd5b0fa2-02f9-489a-bae0-774d7640ee3c
    name: distance
    thingName: 1 - Pass Task - Arduino IoT Cloud
from: 2024-07-10T00:00:00Z
to: 2024-07-24T23:59:59Z

Have fun! :)

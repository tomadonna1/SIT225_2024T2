Arduino Cloud historic data

variables:
  - id: 8debe446-e36f-4fea-bbd9-76479bebe2b5
    name: randomtemp
    thingName: Untitled
from: 2024-07-10T00:00:00Z
to: 2024-07-24T23:59:59Z

Have fun! :)
